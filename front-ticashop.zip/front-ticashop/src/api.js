const API_URL = "http://localhost:8000/api";

// --- Helper para leer el token guardado ---
function getToken() {
  try {
    const raw = localStorage.getItem("ticashop_user");
    if (!raw) return null;
    const user = JSON.parse(raw);
    return user?.token || null;
  } catch {
    return null;
  }
}

function authHeaders() {
  const token = getToken();
  return token ? { Authorization: `Token ${token}` } : {};
}

async function handleJson(res, errorMsg) {
  if (res.ok) return res.json();
  // intenta mostrar detalle del backend si existe
  let detail = "";
  try {
    const data = await res.json();
    detail = data?.detail ? `: ${data.detail}` : "";
  } catch {
    // ignore
  }
  throw new Error(`${errorMsg} (HTTP ${res.status})${detail}`);
}

// ====== PRODUCTOS ======
export async function getProductos() {
  const res = await fetch(`${API_URL}/productos/`, {
    headers: { ...authHeaders() },
  });
  return handleJson(res, "Error al obtener productos");
}

export async function getProducto(id) {
  const res = await fetch(`${API_URL}/productos/${id}/`, {
    headers: { ...authHeaders() },
  });
  return handleJson(res, "Error al obtener producto");
}

export async function crearProducto(producto) {
  const res = await fetch(`${API_URL}/productos/`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify(producto),
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    console.log("❌ Payload enviado:", producto);
    console.log("❌ Error backend:", data);
    throw new Error(JSON.stringify(data));
  }

  return data;
}

export async function actualizarProducto(id, producto) {
  const res = await fetch(`${API_URL}/productos/${id}/`, {
    method: "PUT",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify(producto),
  });
  return handleJson(res, "Error al actualizar producto");
}

export async function deleteProducto(id) {
  const res = await fetch(`${API_URL}/productos/${id}/`, {
    method: "DELETE",
    headers: { ...authHeaders() },
  });
  if (!res.ok) throw new Error(`Error al eliminar producto (HTTP ${res.status})`);
}

// ====== PROVEEDORES ======
export async function getProveedores() {
  const res = await fetch(`${API_URL}/proveedores/`, {
    headers: { ...authHeaders() },
  });
  return handleJson(res, "Error al obtener proveedores");
}

export async function getProveedor(id) {
  const res = await fetch(`${API_URL}/proveedores/${id}/`, {
    headers: { ...authHeaders() },
  });
  return handleJson(res, "Error al obtener proveedor");
}

export async function crearProveedor(data) {
  const res = await fetch(`${API_URL}/proveedores/`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify(data),
  });
  return handleJson(res, "Error al crear proveedor");
}

export async function actualizarProveedor(id, data) {
  const res = await fetch(`${API_URL}/proveedores/${id}/`, {
    method: "PUT",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify(data),
  });
  return handleJson(res, "Error al actualizar proveedor");
}

export async function deleteProveedor(id) {
  const res = await fetch(`${API_URL}/proveedores/${id}/`, {
    method: "DELETE",
    headers: { ...authHeaders() },
  });
  if (!res.ok) throw new Error(`Error al eliminar proveedor (HTTP ${res.status})`);
}

// ====== MOVIMIENTOS DE INVENTARIO ======

// Obtener TODOS los movimientos
export async function getMovimientos() {
  const res = await fetch(`${API_URL}/movimientos/`, {
    headers: { ...authHeaders() },
  });
  return handleJson(res, "Error al obtener movimientos de inventario");
}

// Obtener UN movimiento por id (para editar)
export async function getMovimiento(id) {
  const res = await fetch(`${API_URL}/movimientos/${id}/`, {
    headers: { ...authHeaders() },
  });
  return handleJson(res, "Error al obtener movimiento de inventario");
}

// Crear movimiento
export async function crearMovimiento(data) {
  const res = await fetch(`${API_URL}/movimientos/`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify(data),
  });
  return handleJson(res, "Error al crear movimiento");
}

// Actualizar movimiento
export async function actualizarMovimiento(id, data) {
  const res = await fetch(`${API_URL}/movimientos/${id}/`, {
    method: "PUT",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify(data),
  });
  return handleJson(res, "Error al actualizar movimiento");
}

// Eliminar movimiento
export async function deleteMovimiento(id) {
  const res = await fetch(`${API_URL}/movimientos/${id}/`, {
    method: "DELETE",
    headers: { ...authHeaders() },
  });
  if (!res.ok) throw new Error(`Error al eliminar movimiento (HTTP ${res.status})`);
}