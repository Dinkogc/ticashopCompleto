import React, { useState } from "react";
import { Link } from "react-router-dom";
import Logo from "../assets/logo.png";

export default function Header({ user, onLogout }) {
  const [open, setOpen] = useState(false);

  function closeMenu() {
    setOpen(false);
  }

  return (
    <header className="app-header">
      <div className="header-left">
        <img src={Logo} alt="TicaShop" className="site-logo" />
      </div>

      {/* ✅ Botón hamburguesa (solo móvil) */}
      <button
        className="hamburger"
        onClick={() => setOpen((v) => !v)}
        aria-label="Abrir menú"
      >
        ☰
      </button>

      <nav className={`nav-links ${open ? "open" : ""}`}>
        <Link to="/" onClick={closeMenu}>Inicio</Link>
        <Link to="/products" onClick={closeMenu}>Productos</Link>
        <Link to="/suppliers" onClick={closeMenu}>Proveedores</Link>
        <Link to="/inventory" onClick={closeMenu}>Ingresos</Link>
        <Link to="/outputs" onClick={closeMenu}>Salidas</Link>
        <Link to="/reports" onClick={closeMenu}>Reportes</Link>

        {user ? (
          <span className="header-user">
            {user.name} ({user.role})
            <button
              onClick={() => { closeMenu(); onLogout(); }}
              className="link-button"
            >
              Cerrar sesión
            </button>
          </span>
        ) : (
          <Link to="/login" onClick={closeMenu}>Ingresar</Link>
        )}
      </nav>
    </header>
  );
}