import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getProveedores, deleteProveedor } from "../api";

// ⭐ Formatear fecha
function formatDate(fechaISO) {
  if (!fechaISO || fechaISO === "—") return "—";
  try {
    return new Date(fechaISO).toLocaleDateString("es-CL");
  } catch {
    return "—";
  }
}

export default function Suppliers({ user }) {
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchData() {
      try {
        const data = await getProveedores();

        const mapped = data.map((p) => ({
          id: p.id,
          name: p.nombre,
          rut: p.rut || "—",
          email: p.email || "—",
          phone: p.telefono || "—",
          address: p.direccion || "—",
          category: p.categoria || "—",
          date: p.fechaRegistro || p.fecha_registro || "—",
        }));

        setSuppliers(mapped);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setError("Error al cargar proveedores");
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  async function remove(id) {
    if (user?.role !== "administrador") {
      alert("Solo los administradores pueden eliminar proveedores.");
      return;
    }
    if (!window.confirm("¿Eliminar proveedor?")) return;

    try {
      await deleteProveedor(id);
      setSuppliers(suppliers.filter((s) => s.id !== id));
    } catch (err) {
      console.error(err);
      alert("No se pudo eliminar el proveedor");
    }
  }

  if (loading) return <div>Cargando proveedores...</div>;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <div>
      <div className="page-header">
        <h2>Proveedores</h2>
        {(user?.role === "administrador" || user?.role === "operario") && (
          <Link to="/suppliers/new" className="btn-primary">
            Nuevo proveedor
          </Link>
        )}
      </div>

      {suppliers.length === 0 ? (
        <div className="empty-message">No hay proveedores registrados</div>
      ) : (
        <div className="table-responsive">
          <table className="report-table">
            <thead>
              <tr>
                <th>Nombre</th>
                <th>RUT</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Dirección</th>
                <th>Categoría</th>
                <th>Fecha registro</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {suppliers.map((s) => (
                <tr key={s.id}>
                  <td>{s.name}</td>
                  <td>{s.rut}</td>
                  <td>{s.email}</td>
                  <td>{s.phone}</td>
                  <td>{s.address}</td>
                  <td>{s.category}</td>
                  <td>{formatDate(s.date)}</td>
                  <td>
                    {/* BOTÓN EDITAR */}
                    <Link to={`/suppliers/edit/${s.id}`}>
                      <button className="edit-btn">Editar</button>
                    </Link>

                    {/* BOTÓN ELIMINAR */}
                    {user?.role === "administrador" && (
                      <button
                        onClick={() => remove(s.id)}
                        className="danger"
                        style={{ marginLeft: "5px" }}
                      >
                        Eliminar
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}