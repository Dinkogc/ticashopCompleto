import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { getMovimientos, deleteMovimiento, getProductos } from "../api";

function formatDate(fechaISO) {
  if (!fechaISO || fechaISO === "—") return "—";

  // ✅ Si viene como "YYYY-MM-DD" (DateField de Django), parsearlo como fecha local
  if (typeof fechaISO === "string" && /^\d{4}-\d{2}-\d{2}$/.test(fechaISO)) {
    const [y, m, d] = fechaISO.split("-").map(Number);
    return new Date(y, m - 1, d).toLocaleDateString("es-CL");
  }

  // ✅ Si viene como datetime ISO (DateTimeField), usar Date normal
  const dt = new Date(fechaISO);
  return isNaN(dt.getTime()) ? "—" : dt.toLocaleDateString("es-CL");
}

export default function Outputs({ user }) {
  const [movs, setMovs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const nav = useNavigate();

  useEffect(() => {
    if (!user) nav("/login");
  }, [user, nav]);

  useEffect(() => {
    async function cargar() {
      try {
        // 👉 Traemos movimientos y productos al mismo tiempo
        const [movimientosData, productosData] = await Promise.all([
          getMovimientos(),
          getProductos(),
        ]);

        // Mapa idProducto -> nombre
        const productoMap = {};
        productosData.forEach((p) => {
          productoMap[p.id] = p.nombre;
        });

        // Nos quedamos solo con SALIDAS y armamos datos listos para la tabla
        const salidas = movimientosData
          .filter((m) => m.tipoMovimiento === "SALIDA")
          .map((m) => ({
            id: m.id,
            productoId: m.producto,
            productoNombre: productoMap[m.producto] || m.producto, // 👈 aquí resolvemos el nombre
            cantidad: m.cantidad,
            fecha: m.fecha,
            observacion: m.observacion || m.descripcion || "",
          }));

        setMovs(salidas);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setError("Error al cargar las salidas de inventario");
        setLoading(false);
      }
    }

    cargar();
  }, []);

  async function handleDelete(id) {
    if (!window.confirm("¿Eliminar esta salida de inventario?")) return;
    try {
      await deleteMovimiento(id);
      setMovs((prev) => prev.filter((m) => m.id !== id));
    } catch (err) {
      console.error(err);
      alert("No se pudo eliminar la salida");
    }
  }

  if (loading) return <div>Cargando salidas...</div>;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <div>
      <div className="page-header">
        <h2>Salidas de productos</h2>
        <Link to="/outputs/new" className="btn-primary">
          Nueva salida
        </Link>
      </div>

      {movs.length === 0 ? (
        <div className="empty-message">No hay salidas registradas.</div>
      ) : (
        <div className="table-responsive">
          <table className="report-table">
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Observación</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {movs.map((m) => (
                <tr key={m.id}>
                  <td>{formatDate(m.fecha)}</td>
                  <td>{m.productoNombre}</td>
                  <td>{m.cantidad}</td>
                  <td>{m.observacion || "—"}</td>
                  <td>
                    <button
                      className="danger"
                      onClick={() => handleDelete(m.id)}
                    >
                      Eliminar
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}