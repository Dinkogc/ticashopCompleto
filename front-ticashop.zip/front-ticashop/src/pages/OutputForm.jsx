import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "../FormStyles.css";

import {
  getProductos,
  getMovimiento,
  crearMovimiento,
  actualizarMovimiento,
} from "../api";

export default function OutputForm({ user }) {
  const { id } = useParams();
  const nav = useNavigate();
  const esEdicion = Boolean(id);

  const [productos, setProductos] = useState([]);

  const [productId, setProductId] = useState("");
  const [quantity, setQuantity] = useState(0);
  const [date, setDate] = useState("");
  const [notes, setNotes] = useState("");

  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState(null);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (!user) nav("/login");
  }, [user, nav]);

  useEffect(() => {
    async function cargar() {
      try {
        const productosResp = await getProductos();
        setProductos(productosResp);

        if (esEdicion) {
          const mov = await getMovimiento(id);
          setProductId(mov.producto || "");
          setQuantity(mov.cantidad || 0);
          setDate(mov.fecha ? mov.fecha.slice(0, 10) : "");
          setNotes(mov.observacion || mov.descripcion || "");
        }

        setCargando(false);
      } catch (err) {
        console.error(err);
        setError("Error al cargar datos de la salida");
        setCargando(false);
      }
    }

    cargar();
  }, [esEdicion, id]);

  function getStockActual(pid) {
    const p = productos.find((x) => String(x.id) === String(pid));
    return Number(p?.stockActual ?? 0);
  }

  function validar() {
    const errs = {};

    if (!productId) {
      errs.productId = "Debe seleccionar un producto.";
    }

    const q = Number(quantity);
    if (quantity === "" || quantity === null) {
      errs.quantity = "La cantidad es obligatoria.";
    } else if (Number.isNaN(q) || q <= 0) {
      errs.quantity = "La cantidad debe ser mayor que 0.";
    } else if (!Number.isInteger(q)) {
      errs.quantity = "La cantidad debe ser un número entero.";
    }

    // ✅ Validar stock disponible (muy importante en salidas)
    if (productId) {
      const stock = getStockActual(productId);
      if (!Number.isNaN(q) && q > stock) {
        errs.quantity = `Stock insuficiente. Disponible: ${stock}`;
      }
    }

    if (!date) {
      errs.date = "La fecha es obligatoria.";
    } else {
      const fechaSel = new Date(date);
      const hoy = new Date();
      hoy.setHours(0, 0, 0, 0);
      if (isNaN(fechaSel.getTime())) {
        errs.date = "La fecha no es válida.";
      } else if (fechaSel > hoy) {
        errs.date = "La fecha no puede ser futura.";
      }
    }

    if (notes && notes.length > 200) {
      errs.notes = "Las notas no pueden superar los 200 caracteres.";
    }

    return errs;
  }

  function clearFieldError(field) {
    setErrors((prev) => {
      if (!prev[field]) return prev;
      const copy = { ...prev };
      delete copy[field];
      return copy;
    });
  }

  async function submit(e) {
    e.preventDefault();
    setError(null);

    const validationErrors = validar();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    // ✅ Confirmación antes de registrar (punto 4)
    const ok = window.confirm(
      esEdicion
        ? "¿Confirmas actualizar esta salida?"
        : "¿Confirmas registrar esta salida de producto?"
    );
    if (!ok) return;

    setGuardando(true);

    const payload = {
      producto: Number(productId),
      cantidad: Number(quantity),
      fecha: date,
      observacion: notes,
      tipoMovimiento: "SALIDA",
    };

    try {
      if (esEdicion) await actualizarMovimiento(id, payload);
      else await crearMovimiento(payload);

      nav("/outputs");
    } catch (err) {
      console.error(err);
      setError("Error al guardar la salida de inventario");
    } finally {
      setGuardando(false);
    }
  }

  if (cargando) return <div>Cargando formulario de salida...</div>;

  return (
    <div className="card max-w">
      <h2>{esEdicion ? "Editar salida" : "Nueva salida de producto"}</h2>

      {error && <div className="error-message">{error}</div>}

      <form onSubmit={submit}>
        <label>Producto</label>
        <select
          value={productId}
          onChange={(e) => {
            setProductId(e.target.value);
            clearFieldError("productId");
            clearFieldError("quantity"); // por si era stock insuficiente
          }}
        >
          <option value="">-- Seleccione un producto --</option>
          {productos.map((p) => (
            <option key={p.id} value={p.id}>
              {p.nombre} (stock: {p.stockActual})
            </option>
          ))}
        </select>
        {errors.productId && <p className="error-text">{errors.productId}</p>}

        <label>Cantidad a retirar</label>
        <input
          type="number"
          value={quantity}
          onChange={(e) => {
            setQuantity(e.target.value);
            clearFieldError("quantity");
          }}
          placeholder="Ej: 10"
          min="1"
        />
        {errors.quantity && <p className="error-text">{errors.quantity}</p>}

        <label>Fecha</label>
        <input
          type="date"
          value={date}
          onChange={(e) => {
            setDate(e.target.value);
            clearFieldError("date");
          }}
        />
        {errors.date && <p className="error-text">{errors.date}</p>}

        <label>Notas</label>
        <textarea
          rows="3"
          value={notes}
          onChange={(e) => {
            setNotes(e.target.value);
            clearFieldError("notes");
          }}
          placeholder="Ej: Venta mostrador, boleta 123"
        />
        {errors.notes && <p className="error-text">{errors.notes}</p>}

        <div style={{ textAlign: "right" }}>
          <button className="primary" disabled={guardando}>
            {guardando ? "Guardando..." : "Guardar salida"}
          </button>
        </div>
      </form>
    </div>
  );
}