import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "../FormStyles.css";

import {
  crearProducto,
  actualizarProducto,
  getProducto,
  getProveedores,
} from "../api";

export default function ProductForm({ user }) {
  const { id } = useParams();
  const navigate = useNavigate();

  const esEdicion = Boolean(id);

  const [proveedores, setProveedores] = useState([]);
  const [categorias, setCategorias] = useState([]);

  const [formData, setFormData] = useState({
    codigo: `PRD-${Date.now().toString().slice(-5)}`,
    nombre: "",
    categoria: "",
    precioUnitario: "",
    fechaIngreso: "",
    stockActual: 0,
    proveedor: "",
  });

  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState(null);

  // 🔎 errores de validación
  const [errors, setErrors] = useState({});

  // PROTEGER LA RUTA
  useEffect(() => {
    if (!user) navigate("/login");
  }, [user, navigate]);

  // CARGAR PROVEEDORES Y PRODUCTO (SI EDITA)
  useEffect(() => {
    async function cargar() {
      try {
        const provs = await getProveedores();
        setProveedores(provs);

        const catsRes = await fetch("http://localhost:8000/api/categorias/");
        const cats = await catsRes.json();
        setCategorias(cats);

        if (esEdicion) {
          const producto = await getProducto(id);

          setFormData({
            codigo: producto.codigo,
            nombre: producto.nombre || "",
            categoria: producto.categoria ? String(producto.categoria) : "",
            precioUnitario: producto.precioUnitario ?? "",
            fechaIngreso: producto.fechaIngreso || "",
            stockActual: producto.stockActual ?? 0,
            proveedor: producto.proveedor || "",
          });
        }
      } catch (err) {
        console.error(err);
        setError("Error al cargar el formulario");
      } finally {
        setCargando(false);
      }
    }

    cargar();
  }, [esEdicion, id]);

  function handleChange(e) {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    // ✅ mejora: al escribir, borra el error de ese campo
    setErrors((prev) => {
      if (!prev[name]) return prev;
      const copy = { ...prev };
      delete copy[name];
      return copy;
    });
  }

  // ✅ VALIDACIONES DEL FORMULARIO
  function validarProducto(values) {
    const errs = {};

    // Nombre
    if (!values.nombre.trim()) {
      errs.nombre = "El nombre es obligatorio.";
    } else if (values.nombre.trim().length < 3) {
      errs.nombre = "El nombre debe tener al menos 3 caracteres.";
    }

    // Categoría
    if (!values.categoria) {
      errs.categoria = "Debe seleccionar una categoría.";
    }

    // Precio
    const precio = Number(values.precioUnitario);
    if (values.precioUnitario === "" || values.precioUnitario === null) {
      errs.precioUnitario = "El precio es obligatorio.";
    } else if (Number.isNaN(precio) || precio <= 0) {
      errs.precioUnitario = "El precio debe ser un número mayor que 0.";
    }

    // Fecha ingreso
    if (!values.fechaIngreso) {
      errs.fechaIngreso = "La fecha de ingreso es obligatoria.";
    } else {
      const fechaSel = new Date(values.fechaIngreso);
      const hoy = new Date();
      hoy.setHours(0, 0, 0, 0);
      if (isNaN(fechaSel.getTime())) {
        errs.fechaIngreso = "La fecha no es válida.";
      } else if (fechaSel > hoy) {
        errs.fechaIngreso = "La fecha no puede ser futura.";
      }
    }

    // Proveedor
    if (!values.proveedor) {
      errs.proveedor = "Debe seleccionar un proveedor.";
    }

    // Stock inicial
    const stock = Number(values.stockActual);
    if (values.stockActual === "" || values.stockActual === null) {
      errs.stockActual = "El stock inicial es obligatorio.";
    } else if (Number.isNaN(stock) || stock < 0) {
      errs.stockActual =
        "El stock inicial debe ser un número mayor o igual a 0.";
    } else if (!Number.isInteger(stock)) {
      errs.stockActual = "El stock inicial debe ser un número entero.";
    }

    return errs;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);

    // correr validaciones
    const validationErrors = validarProducto(formData);
    setErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) return;

    // ✅ CONFIRMACIÓN ANTES DE REGISTRAR (punto 4)
    const ok = window.confirm(
      esEdicion
        ? "¿Confirmas actualizar este producto?"
        : "¿Confirmas registrar este producto?"
    );
    if (!ok) return;

    setGuardando(true);

    const payload = {
      codigo: formData.codigo,
      nombre: formData.nombre.trim(),
      categoria: Number(formData.categoria),
      precioUnitario: Number(formData.precioUnitario),
      fechaIngreso: formData.fechaIngreso,
      stockActual: Number(formData.stockActual),
      proveedor: Number(formData.proveedor),
    };

    try {
      if (esEdicion) {
        await actualizarProducto(id, payload);
      } else {
        await crearProducto(payload);
      }

      navigate("/products");
    } catch (err) {
      console.error(err);
      setError("Error al guardar el producto");
    } finally {
      setGuardando(false);
    }
  }

  if (cargando) return <div>Cargando...</div>;

  return (
    <div className="form-container">
      <h2>{esEdicion ? "Editar producto" : "Nuevo producto"}</h2>

      {error && <div className="error-message">{error}</div>}

      <form onSubmit={handleSubmit} className="responsive-form">
        <div className="form-group">
          <label>Código</label>
          <input type="text" value={formData.codigo} disabled />
        </div>

        <div className="form-group">
          <label>Nombre</label>
          <input
            type="text"
            name="nombre"
            value={formData.nombre}
            onChange={handleChange}
          />
          {errors.nombre && <p className="error-text">{errors.nombre}</p>}
        </div>

        <div className="form-group">
          <label>Categoría</label>
          <select
            name="categoria"
            value={formData.categoria}
            onChange={handleChange}
          >
            <option value="">-- Seleccione --</option>
            {categorias.map((c) => (
              <option key={c.id} value={c.id}>
                {c.nombre}
              </option>
            ))}
          </select>
          {errors.categoria && <p className="error-text">{errors.categoria}</p>}
        </div>

        <div className="form-group">
          <label>Precio</label>
          <input
            type="number"
            name="precioUnitario"
            value={formData.precioUnitario}
            onChange={handleChange}
          />
          {errors.precioUnitario && (
            <p className="error-text">{errors.precioUnitario}</p>
          )}
        </div>

        <div className="form-group">
          <label>Fecha ingreso</label>
          <input
            type="date"
            name="fechaIngreso"
            value={formData.fechaIngreso}
            onChange={handleChange}
          />
          {errors.fechaIngreso && (
            <p className="error-text">{errors.fechaIngreso}</p>
          )}
        </div>

        <div className="form-group">
          <label>Proveedor</label>
          <select
            name="proveedor"
            value={formData.proveedor}
            onChange={handleChange}
          >
            <option value="">-- Seleccione proveedor --</option>
            {proveedores.map((p) => (
              <option key={p.id} value={p.id}>
                {p.nombre}
              </option>
            ))}
          </select>
          {errors.proveedor && <p className="error-text">{errors.proveedor}</p>}
        </div>

        <div className="form-group">
          <label>Stock inicial</label>
          <input
            type="number"
            name="stockActual"
            value={formData.stockActual}
            onChange={handleChange}
            min="0"
          />
          {errors.stockActual && (
            <p className="error-text">{errors.stockActual}</p>
          )}
        </div>

        <div className="button-container">
          <button type="submit" className="submit-btn" disabled={guardando}>
            {guardando ? "Guardando..." : "Guardar producto"}
          </button>
        </div>
      </form>
    </div>
  );
}