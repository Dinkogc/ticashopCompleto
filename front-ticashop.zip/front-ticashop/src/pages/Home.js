import React from "react";

function Home() {
  return (
    <main>
      <h2>Bienvenidos a TICASHOP LATAM</h2>
      <p>Compra productos de calidad al mejor precio.</p>
    </main>
  );
}

export default Home;