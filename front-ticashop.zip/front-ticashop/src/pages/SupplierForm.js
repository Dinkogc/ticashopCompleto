import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import "../FormStyles.css";

import { getProveedor, crearProveedor, actualizarProveedor } from "../api";

export default function SupplierForm({ user }) {
  const { id } = useParams();
  const nav = useNavigate();
  const esEdicion = Boolean(id);

  const [name, setName] = useState("");
  const [rut, setRut] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");

  const [cargando, setCargando] = useState(true);
  const [guardando, setGuardando] = useState(false);
  const [error, setError] = useState(null);

  const [errors, setErrors] = useState({});

  // Proteger ruta
  useEffect(() => {
    if (!user) nav("/login");
  }, [user, nav]);

  // Cargar proveedor si estamos editando
  useEffect(() => {
    async function cargar() {
      try {
        if (esEdicion) {
          const proveedor = await getProveedor(id);
          setName(proveedor.nombre || "");
          setRut(proveedor.rut || "");
          setEmail(proveedor.email || "");
          setPhone(proveedor.telefono || "");
          setAddress(proveedor.direccion || "");
        }
      } catch (err) {
        console.error(err);
        setError("Error al cargar proveedor");
      } finally {
        setCargando(false);
      }
    }
    cargar();
  }, [esEdicion, id]);

  // ✅ VALIDACIONES
  function validarProveedor() {
    const errs = {};

    if (!name.trim()) errs.name = "El nombre es obligatorio.";
    else if (name.trim().length < 3)
      errs.name = "El nombre debe tener al menos 3 caracteres.";

    if (!rut.trim()) {
      errs.rut = "El RUT es obligatorio.";
    } else {
      const rutRegex = /^\d{1,2}\.?\d{3}\.?\d{3}-[\dkK]$/;
      if (!rutRegex.test(rut.trim())) {
        errs.rut = "El RUT debe tener formato válido (ej: 12.345.678-9).";
      }
    }

    if (!email.trim()) {
      errs.email = "El correo electrónico es obligatorio.";
    } else {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(email.trim())) {
        errs.email = "Ingrese un correo electrónico válido.";
      }
    }

    if (phone && phone.trim().length > 0 && phone.trim().length < 8) {
      errs.phone = "El teléfono debe tener al menos 8 caracteres.";
    }

    if (address && address.trim().length > 150) {
      errs.address = "La dirección no puede superar los 150 caracteres.";
    }

    return errs;
  }

  // ✅ helpers: setters que limpian error del campo
  function setField(setter, field) {
    return (e) => {
      setter(e.target.value);
      setErrors((prev) => {
        if (!prev[field]) return prev;
        const copy = { ...prev };
        delete copy[field];
        return copy;
      });
    };
  }

  async function submit(e) {
    e.preventDefault();
    setError(null);

    const validationErrors = validarProveedor();
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;

    // ✅ CONFIRMACIÓN ANTES DE REGISTRAR (punto 4)
    const ok = window.confirm(
      esEdicion
        ? "¿Confirmas actualizar este proveedor?"
        : "¿Confirmas registrar este proveedor?"
    );
    if (!ok) return;

    setGuardando(true);

    const payload = {
      nombre: name.trim(),
      rut: rut.trim(),
      email: email.trim(),
      telefono: phone.trim(),
      direccion: address.trim(),
    };

    try {
      if (esEdicion) await actualizarProveedor(id, payload);
      else await crearProveedor(payload);

      nav("/suppliers");
    } catch (err) {
      console.error(err);
      setError("Error al guardar proveedor");
    } finally {
      setGuardando(false);
    }
  }

  if (cargando) return <div>Cargando...</div>;

  return (
    <div className="card max-w">
      <h2>{esEdicion ? "Editar proveedor" : "Nuevo proveedor"}</h2>

      {error && <div className="error-message">{error}</div>}

      <form onSubmit={submit}>
        <label>Nombre</label>
        <input
          value={name}
          onChange={setField(setName, "name")}
          placeholder="Ej: Proveedor ABC Ltda."
        />
        {errors.name && <p className="error-text">{errors.name}</p>}

        <label>RUT</label>
        <input
          value={rut}
          onChange={setField(setRut, "rut")}
          placeholder="Ej: 76.123.456-7"
        />
        {errors.rut && <p className="error-text">{errors.rut}</p>}

        <label>Correo electrónico</label>
        <input
          type="email"
          value={email}
          onChange={setField(setEmail, "email")}
          placeholder="correo@ejemplo.com"
        />
        {errors.email && <p className="error-text">{errors.email}</p>}

        <label>Teléfono</label>
        <input
          type="tel"
          value={phone}
          onChange={setField(setPhone, "phone")}
          placeholder="+56 9 8765 4321"
        />
        {errors.phone && <p className="error-text">{errors.phone}</p>}

        <label>Dirección</label>
        <input
          value={address}
          onChange={setField(setAddress, "address")}
          placeholder="Ej: Av. Las Flores 123, Santiago"
        />
        {errors.address && <p className="error-text">{errors.address}</p>}

        <div style={{ textAlign: "right" }}>
          <button className="primary" disabled={guardando}>
            {guardando ? "Guardando..." : "Guardar"}
          </button>
        </div>
      </form>
    </div>
  );
}