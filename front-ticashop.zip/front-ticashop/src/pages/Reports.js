import React, { useEffect, useState } from "react";

function formatDate(fechaISO) {
  if (!fechaISO || fechaISO === "—") return "—";

  // ✅ Si viene como "YYYY-MM-DD" (DateField Django)
  if (typeof fechaISO === "string" && /^\d{4}-\d{2}-\d{2}$/.test(fechaISO)) {
    const [y, m, d] = fechaISO.split("-").map(Number);
    return new Date(y, m - 1, d).toLocaleDateString("es-CL");
  }

  // ✅ Si viene como DateTime ISO: formatear en UTC para que NO se corra 1 día
  const dt = new Date(fechaISO);
  if (isNaN(dt.getTime())) return "—";

  return dt.toLocaleDateString("es-CL", { timeZone: "UTC" });
}

export default function Reports() {
  const [summary, setSummary] = useState([]);
  const [detail, setDetail] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function cargar() {
      try {
        const resp = await fetch("http://localhost:8000/api/reporte-inventario/");
        if (!resp.ok) throw new Error("Error HTTP " + resp.status);

        const data = await resp.json();

        setSummary(data.resumen || []);
        setDetail(data.detalle || []);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setError("Error al cargar el reporte de inventario");
        setLoading(false);
      }
    }

    cargar();
  }, []);

  // ----- CSV -----

  function escapeCsv(value) {
    if (value === null || value === undefined) return "";
    const str = String(value);
    if (/[",\n;]/.test(str)) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  }

  function descargarCSV() {
    if (summary.length === 0 && detail.length === 0) {
      alert("No hay datos para generar el reporte.");
      return;
    }

    let csv = "REPORTE DE INVENTARIO\n\n";

    // Sección 1: Resumen
    csv += "Resumen por producto\n";
    csv += "Producto;Stock actual;Ingresado total\n";
    summary.forEach((r) => {
      csv += [
        escapeCsv(r.producto),
        escapeCsv(r.stockActual),
        escapeCsv(r.totalIngresado),
      ].join(";") + "\n";
    });

    // Sección 2: Detalle (con usuario)
    csv += "\nDetalle de movimientos\n";
    csv += "ID;Fecha;Producto;Tipo;Cantidad;Usuario;Observación\n";
    detail.forEach((m) => {
      csv += [
        escapeCsv(m.id),
        escapeCsv(formatDate(m.fecha)),
        escapeCsv(m.producto),
        escapeCsv(m.tipo),
        escapeCsv(m.cantidad),
        escapeCsv(m.usuario || ""),          // ✅ NUEVO
        escapeCsv(m.observacion),
      ].join(";") + "\n";
    });

    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", "reporte_inventario.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  // ----- RENDER -----

  if (loading) return <div>Cargando reportes...</div>;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <div>
      <div className="page-header">
        <h2>Reportes de Inventario</h2>
        {(summary.length > 0 || detail.length > 0) && (
          <button className="btn-primary" onClick={descargarCSV}>
            Descargar CSV
          </button>
        )}
      </div>

      {/* TABLA 1: RESUMEN POR PRODUCTO */}
      <div className="report-container">
        <h3>Resumen por producto</h3>
        <div className="table-responsive">
          <table className="report-table improved">
            <thead>
              <tr>
                <th>Producto</th>
                <th>Stock actual</th>
                <th>Ingresado (total)</th>
              </tr>
            </thead>
            <tbody>
              {summary.length === 0 ? (
                <tr>
                  <td colSpan="3" style={{ textAlign: "center" }}>
                    No hay productos
                  </td>
                </tr>
              ) : (
                summary.map((r, i) => (
                  <tr key={i}>
                    <td>{r.producto}</td>
                    <td>{r.stockActual}</td>
                    <td>{r.totalIngresado}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* TABLA 2: DETALLE DE MOVIMIENTOS */}
      <div className="report-container" style={{ marginTop: "2rem" }}>
        <h3>Detalle de movimientos</h3>
        <div className="table-responsive">
          <table className="report-table improved">
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Producto</th>
                <th>Tipo</th>
                <th>Cantidad</th>
                <th>Usuario</th>       {/* ✅ NUEVO */}
                <th>Observación</th>
              </tr>
            </thead>
            <tbody>
              {detail.length === 0 ? (
                <tr>
                  <td colSpan="6" style={{ textAlign: "center" }}>
                    No hay movimientos registrados
                  </td>
                </tr>
              ) : (
                detail.map((m) => (
                  <tr key={m.id}>
                    <td>{formatDate(m.fecha)}</td>
                    <td>{m.producto}</td>
                    <td>{m.tipo}</td>
                    <td>{m.cantidad}</td>
                    <td>{m.usuario || "—"}</td>  {/* ✅ NUEVO */}
                    <td>{m.observacion || "—"}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}