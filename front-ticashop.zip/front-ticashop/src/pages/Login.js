import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

// seguimos usando tu store para guardar el usuario en localStorage
import { save } from "../lib/store";

const API_URL = "http://localhost:8000/api";

export default function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const nav = useNavigate();

  async function submit(e) {
    e.preventDefault();
    console.log("ENVIANDO LOGIN", username, password);
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(`${API_URL}/login/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      if (!res.ok) {
        throw new Error("Credenciales inválidas");
      }

      const data = await res.json();

      // Este será el usuario que usará toda la app
      const user = {
        name: data.username,
        role: data.role,     // "administrador" o "operario" desde Django
        token: data.token,   // lo usaremos para las demás peticiones
      };

      // Guardar en localStorage, como antes
      save("ticashop_user", user);

      // Avisar al componente padre
      onLogin(user);

      // Navegar al inicio
      nav("/");

    } catch (err) {
      console.error(err);
      setError("Usuario o contraseña incorrectos");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card login-card">
      <h2>Ingresar a TiCaShop</h2>
      <form onSubmit={submit}>
        <label>Usuario</label>
        <input
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="Ej: admin"
          required
        />

        <label>Contraseña</label>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        {error && (
          <div style={{ color: "red", marginTop: "8px" }}>
            {error}
          </div>
        )}

        <div style={{ textAlign: "right", marginTop: "12px" }}>
          <button
            type="button"
            className="primary"
            disabled={loading}
            onClick={submit}
          >
            {loading ? "Ingresando..." : "Entrar"}
          </button>
        </div>
      </form>
    </div>
  );
}