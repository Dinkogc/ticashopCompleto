import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getProductos, deleteProducto } from "../api";

const MIN_STOCK = 5; // 🔥 stock mínimo predeterminado

function formatDate(fechaISO) {
  if (!fechaISO || fechaISO === "—") return "—";

  // ✅ Si viene como "YYYY-MM-DD" (DateField de Django), parsearlo como fecha local
  if (typeof fechaISO === "string" && /^\d{4}-\d{2}-\d{2}$/.test(fechaISO)) {
    const [y, m, d] = fechaISO.split("-").map(Number);
    return new Date(y, m - 1, d).toLocaleDateString("es-CL");
  }

  // ✅ Si viene como datetime ISO (DateTimeField), usar Date normal
  const dt = new Date(fechaISO);
  return isNaN(dt.getTime()) ? "—" : dt.toLocaleDateString("es-CL");
}

export default function Products({ user }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Cargar productos desde el backend al montar el componente
  useEffect(() => {
    async function fetchData() {
      try {
        const data = await getProductos();

        // Mapeo de campos del backend
        const mapped = data.map((p) => ({
          id: p.id,
          name: p.nombre,
          code: p.codigo,
          category: p.categoria || "—",
          price: p.precioUnitario,
          date: p.fechaIngreso || p.fecha_ingreso || "—",
          stock: p.stockActual,
        }));

        setProducts(mapped);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setError("Error al cargar productos");
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  async function remove(id) {
    if (user?.role !== "administrador") {
      alert("Solo administradores pueden eliminar productos.");
      return;
    }
    if (!window.confirm("¿Eliminar producto?")) return;

    try {
      await deleteProducto(id);
      setProducts(products.filter((p) => p.id !== id));
    } catch (err) {
      console.error(err);
      alert("No se pudo eliminar el producto");
    }
  }

  if (loading) {
    return <div>Cargando productos...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div>
      <div className="page-header">
        <h2>Productos</h2>
        {(user?.role === "administrador" || user?.role === "operario") && (
          <Link to="/products/new" className="btn-primary">
            Nuevo producto
          </Link>
        )}
      </div>

      {products.length === 0 ? (
        <div className="empty-message">No hay productos registrados</div>
      ) : (
        <div className="table-responsive">
          <table className="report-table">
            <thead>
              <tr>
                <th>Código</th>
                <th>Nombre</th>
                <th>Categoría</th>
                <th>Precio</th>
                <th>Fecha ingreso</th>
                <th>Stock</th>
                <th>Estado</th>
                <th>Acciones</th>
              </tr>
            </thead>
            <tbody>
              {products.map((p) => {
                const stock = Number(p.stock ?? 0);
                const isLow = stock <= MIN_STOCK;

                return (
                  <tr key={p.id}>
                    <td>{p.code}</td>
                    <td>{p.name}</td>
                    <td>{p.category}</td>

                    {/* PRECIO en CLP */}
                    <td>
                      {p.price
                        ? Number(p.price).toLocaleString("es-CL", {
                            style: "currency",
                            currency: "CLP",
                            minimumFractionDigits: 0, // sin decimales
                          })
                        : "—"}
                    </td>

                    <td>{formatDate(p.date)}</td>
                    <td>{stock}</td>
                    <td>
                      {isLow ? (
                        <span className="badge-low">
                          Stock bajo – reponer
                        </span>
                      ) : (
                        <span className="badge-ok">Stock suficiente</span>
                      )}
                    </td>
                    <td>
                      {/* BOTÓN EDITAR */}
                      <Link to={`/products/edit/${p.id}`}>
                        <button className="edit-btn">Editar</button>
                      </Link>{" "}
                      {/* BOTÓN ELIMINAR */}
                      {user?.role === "administrador" && (
                        <button
                          onClick={() => remove(p.id)}
                          className="danger"
                          style={{ marginLeft: "5px" }}
                        >
                          Eliminar
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}