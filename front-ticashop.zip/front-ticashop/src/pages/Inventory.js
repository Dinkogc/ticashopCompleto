import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  getMovimientos,
  deleteMovimiento,
  getProveedores,
  getProductos,
} from "../api";

const MIN_STOCK = 5;

function formatDate(fechaISO) {
  if (!fechaISO || fechaISO === "—") return "—";

  // ✅ Si viene como "YYYY-MM-DD" (DateField de Django), parsearlo como fecha local
  if (typeof fechaISO === "string" && /^\d{4}-\d{2}-\d{2}$/.test(fechaISO)) {
    const [y, m, d] = fechaISO.split("-").map(Number);
    return new Date(y, m - 1, d).toLocaleDateString("es-CL");
  }

  // ✅ Si viene como datetime ISO (DateTimeField), usar Date normal
  const dt = new Date(fechaISO);
  return isNaN(dt.getTime()) ? "—" : dt.toLocaleDateString("es-CL");
}

export default function Inventory({ user }) {
  const [movimientos, setMovimientos] = useState([]);
  const [proveedores, setProveedores] = useState({});
  const [productos, setProductos] = useState({});

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchData() {
      try {
        const [movs, provs, prods] = await Promise.all([
          getMovimientos(),
          getProveedores(),
          getProductos(),
        ]);

        const proveedoresMap = provs.reduce((acc, p) => {
          acc[p.id] = p;
          return acc;
        }, {});

        const productosMap = prods.reduce((acc, p) => {
          acc[p.id] = p;
          return acc;
        }, {});

        const mappedMovs = movs.map((m) => {
          const prod = productosMap[m.producto] || {};

          return {
            id: m.id,
            productId: m.producto,
            proveedorId: prod.proveedor || null,
            categoria: prod.categoria || "—",
            descripcion: prod.descripcion || "—",
            cantidad: Number(m.cantidad || 0),
            tipo: m.tipoMovimiento || "—", // ✅ NUEVO
            precio: Number(m.precioUnitario ?? prod.precioUnitario ?? 0),
            total:
              Number(m.total) ||
              Number(m.cantidad || 0) *
                Number(m.precioUnitario ?? prod.precioUnitario ?? 0),
            fecha: m.fecha,
            stock: Number(prod.stockActual ?? 0),
          };
        });

        setProveedores(proveedoresMap);
        setProductos(productosMap);
        setMovimientos(mappedMovs);
        setLoading(false);
      } catch (err) {
        console.error(err);
        setError("Error al cargar el inventario");
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  function getProveedorName(id) {
    if (!id) return "—";
    return proveedores[id]?.nombre || "—";
  }

  function getProductName(id) {
    if (!id) return "—";
    return productos[id]?.nombre || "—";
  }

  async function remove(id) {
    if (user?.role !== "administrador") {
      alert("Solo administradores pueden eliminar movimientos.");
      return;
    }
    if (!window.confirm("¿Eliminar movimiento?")) return;

    try {
      await deleteMovimiento(id);
      setMovimientos(movimientos.filter((m) => m.id !== id));
    } catch (err) {
      console.error(err);
      alert("No se pudo eliminar el movimiento");
    }
  }

  if (loading) return <div>Cargando inventario...</div>;
  if (error) return <div className="error-message">{error}</div>;

  return (
    <div>
      <div className="page-header">
        <h2>Inventario (Movimientos)</h2>

        {(user?.role === "administrador" || user?.role === "operario") && (
          <Link to="/inventory/new" className="btn-primary">
            Nuevo ingreso
          </Link>
        )}
      </div>

      {movimientos.length === 0 ? (
        <div className="empty-message">No hay movimientos registrados</div>
      ) : (
        <div className="table-responsive">
          <table className="report-table">
            <thead>
              <tr>
                <th>Fecha</th>
                <th>Tipo</th> {/* ✅ NUEVO */}
                <th>Producto</th>
                <th>Categoría</th>
                <th>Proveedor</th>
                <th>Descripción</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Total</th>
                <th>Stock actual</th>
                <th>Estado stock</th>
                <th>Acciones</th>
              </tr>
            </thead>

            <tbody>
              {movimientos.map((m) => {
                const stock = Number(m.stock ?? 0);
                const isLow = stock <= MIN_STOCK;

                return (
                  <tr key={m.id}>
                    <td>{formatDate(m.fecha)}</td>
                    <td>{m.tipo}</td>
                    <td>{getProductName(m.productId)}</td>
                    <td>{m.categoria}</td>
                    <td>{getProveedorName(m.proveedorId)}</td>
                    <td>{m.descripcion}</td>
                    <td>{m.cantidad}</td>
                    <td>${Number(m.precio).toLocaleString("es-CL")}</td>
                    <td>${Number(m.total).toLocaleString("es-CL")}</td>
                    <td>{stock}</td>
                    <td>
                      {isLow ? (
                        <span className="badge-low">Stock bajo – reponer</span>
                      ) : (
                        <span className="badge-ok">Stock suficiente</span>
                      )}
                    </td>

                    <td>
                      <Link to={`/inventory/edit/${m.id}`}>
                        <button className="edit-btn">Editar</button>
                      </Link>{" "}
                      {user?.role === "administrador" && (
                        <button
                          onClick={() => remove(m.id)}
                          className="danger"
                          style={{ marginLeft: "5px", padding: "4px 8px" }}
                        >
                          Eliminar
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}