from django.contrib.auth import authenticate
from django.db.models import Sum
from rest_framework import viewsets, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from rest_framework.permissions import AllowAny

from .models import Producto, Proveedor, MovimientoInventario
from .serializers import (
    ProductoSerializer,
    ProveedorSerializer,
    MovimientoInventarioSerializer,
)


# -----------------------
#   VIEWSETS BÁSICOS
# -----------------------

class ProveedorViewSet(viewsets.ModelViewSet):
    queryset = Proveedor.objects.all()
    serializer_class = ProveedorSerializer


class ProductoViewSet(viewsets.ModelViewSet):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer


class MovimientoInventarioViewSet(viewsets.ModelViewSet):
    queryset = MovimientoInventario.objects.all()
    serializer_class = MovimientoInventarioSerializer

    def perform_create(self, serializer):
        """
        Cuando se crea un movimiento:
        - ENTRADA  -> suma al stockActual
        - SALIDA   -> resta del stockActual
        - AJUSTE   -> fija el stockActual a la cantidad indicada
        """
        movimiento = serializer.save()

        producto = movimiento.producto
        cantidad = movimiento.cantidad or 0

        if movimiento.tipoMovimiento == "ENTRADA":
            producto.stockActual = (producto.stockActual or 0) + cantidad

        elif movimiento.tipoMovimiento == "SALIDA":
            producto.stockActual = (producto.stockActual or 0) - cantidad

        elif movimiento.tipoMovimiento == "AJUSTE":
            producto.stockActual = cantidad

        producto.save()


# -----------------------
#   REPORTE INVENTARIO
# -----------------------

class ReporteInventarioView(APIView):
    """
    Devuelve una lista de productos con:
    - nombre
    - stockActual
    - totalIngresado (suma de movimientos tipo ENTRADA)
    """

    def get(self, request):
        productos = Producto.objects.all()
        data = []

        for p in productos:
            total_entrada = MovimientoInventario.objects.filter(
                producto=p,
                tipoMovimiento="ENTRADA"
            ).aggregate(total=Sum("cantidad"))["total"] or 0

            data.append({
                "producto": p.nombre,
                "stockActual": p.stockActual,
                "totalIngresado": total_entrada,
            })

        return Response(data, status=status.HTTP_200_OK)


# -----------------------
#   LOGIN
# -----------------------

class LoginView(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]

    def post(self, request):
        username = request.data.get("username")
        password = request.data.get("password")

        user = authenticate(username=username, password=password)

        if user is None:
            return Response(
                {"detail": "Credenciales inválidas"},
                status=status.HTTP_401_UNAUTHORIZED
            )

        token, created = Token.objects.get_or_create(user=user)

        role = "administrador" if user.is_staff else "operario"

        return Response({
            "token": token.key,
            "username": user.username,
            "role": role,
        }, status=status.HTTP_200_OK)