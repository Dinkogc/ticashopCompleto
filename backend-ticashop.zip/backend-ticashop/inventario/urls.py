from django.urls import path
from rest_framework.routers import DefaultRouter

from .views import (
    ProveedorViewSet,
    ProductoViewSet,
    MovimientoInventarioViewSet,
    ReporteInventarioView,
    LoginView,
)

router = DefaultRouter()
router.register(r'productos', ProductoViewSet, basename='producto')
router.register(r'proveedores', ProveedorViewSet, basename='proveedor')
router.register(r'movimientos', MovimientoInventarioViewSet, basename='movimiento')

urlpatterns = [
    # /api/login/
    path('login/', LoginView.as_view(), name='login'),

    # /api/reporte-inventario/
    path('reporte-inventario/', ReporteInventarioView.as_view(), name='reporte-inventario'),
]

# Rutas de los viewsets: /api/productos/, /api/proveedores/, /api/movimientos/
urlpatterns += router.urls